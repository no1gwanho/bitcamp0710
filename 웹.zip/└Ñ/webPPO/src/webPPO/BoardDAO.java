package webPPO;

public class BoardDAO {

}
