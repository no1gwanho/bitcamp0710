import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableModel;

public class MainMenu extends JFrame implements ActionListener{

	
	//���� ������ �г�
	JPanel salesMasPane = new JPanel(new BorderLayout());
				
	//���� ���
		JPanel salesTitlePane = new JPanel(new GridLayout(2,1));
			JPanel salesBlankPanel = new JPanel();
				JLabel salesBlankLbl = new JLabel(" ");
			JPanel salesTiltPaneset = new JPanel(new FlowLayout(FlowLayout.CENTER));
				JLabel salesTitleLbl = new JLabel("�����޴�");
	//���� ����
		JPanel salesCenterPane = new JPanel(new GridLayout(2,2,100,50));
			JButton salesSalesBtn = new JButton("Ȧ����");
			JButton salesStockBtn = new JButton("����Ӻ�");
			JButton salesSalConBtn = new JButton("��������");
			JButton salesOffBtn = new JButton("�޴��߰�");
	///////////////////////////////////////////////////////////////////////////		
			
			
	//���� ������ �г�
		JPanel mainMasPane = new JPanel(new BorderLayout());
						
	//���� ���
		JPanel mainTitlePane = new JPanel(new GridLayout(2,1));
			JPanel mainBlankPanel = new JPanel();
				JLabel mainBlankLbl = new JLabel(" ");
				JPanel mainTiltPaneset = new JPanel(new FlowLayout(FlowLayout.CENTER));
				JLabel mainTitleLbl = new JLabel("����ȭ��");
	//���� ����
		JPanel mainCenterPane = new JPanel(new GridLayout(2,2,100,50));
			JButton mainSalesBtn = new JButton("�����޴�");
			JButton mainStockBtn = new JButton("�������");
			JButton mainSalConBtn = new JButton("��������");
			JButton mainOffBtn = new JButton("���α׷� ����");
			
			
	//////////////////////////////////////////////////////////////////////////////			
	
	
	//Ȧ ���� �޴�  ���̺� ����
			
	JPanel tableMasPane = new JPanel(new BorderLayout());
		JPanel tablePane = new JPanel(new GridLayout(2,3,30,20));			
			
			JPanel table1 = new JPanel(new BorderLayout());
				JLabel table1Lbl = new JLabel("Table1");
				JTextArea tableBox1 = new JTextArea();	
				JScrollPane tableScroll1 = new JScrollPane(tableBox1);
	
			JPanel table2 = new JPanel(new BorderLayout());
				JLabel table2Lbl = new JLabel("Table2");
				JTextArea tableBox2 = new JTextArea();
				JScrollPane tableScroll2 = new JScrollPane(tableBox2);
	
			JPanel table3 = new JPanel(new BorderLayout());
				JLabel table3Lbl = new JLabel("Table3");
				JTextArea tableBox3 = new JTextArea();
				JScrollPane tableScroll3 = new JScrollPane(tableBox3);
	
			JPanel table4 = new JPanel(new BorderLayout());
				JLabel table4Lbl = new JLabel("Table4");
				JTextArea tableBox4 = new JTextArea();
				JScrollPane tableScroll4 = new JScrollPane(tableBox4);
		
			JPanel table5 = new JPanel(new BorderLayout());
				JLabel table5Lbl = new JLabel("Table5");
				JTextArea tableBox5 = new JTextArea();
				JScrollPane tableScroll5 = new JScrollPane(tableBox5);
	
			
			JPanel table6 = new JPanel(new BorderLayout());
				JLabel table6Lbl = new JLabel("Table6");
				JTextArea tableBox6 = new JTextArea();
				JScrollPane tableScroll6 = new JScrollPane(tableBox6);
		
		JPanel tableBackPane = new JPanel(new GridLayout(1,3,30,20));
			JLabel tableBlank1 = new JLabel("");
			JLabel tableBlank2 = new JLabel("");
			JButton tableBackBtn = new JButton("�ڷΰ���");
	//////////////////////////////////////////////////////////////////////////////
			
	
			
			
	//�ֹ�ȭ�� ���� ����
			JPanel orderMasPane = new JPanel(new GridLayout(1,2,20,0)); //�¿��� �����׸����г�		
			
			
			
			
	//���� �ֹ���Ȳ ���� ����
	
		JPanel orderStatePane = new JPanel(new BorderLayout());
			JPanel orderTitlePane = new JPanel();
				JLabel orderTitleLbl = new JLabel("�ֹ���Ȳ");
		
			JPanel orderTableMasPane = new JPanel(new BorderLayout());
				JPanel orderTablePane = new JPanel();
					JLabel orderTableLbl = new JLabel("Table1");
					
				String orderTableTitle [] = {"ǰ��","����","�ݾ�"};
				DefaultTableModel orderModel= new DefaultTableModel(orderTableTitle,0);
				JTable orderTableList = new JTable(orderModel);
				JScrollPane orderSp = new JScrollPane(orderTableList);
		
			JPanel orderBtnPane = new JPanel();
				JButton orderButton = new JButton("�ֹ��� ����");
	


				
				
				
				
	
				
				
				
				
	//���� �޴� ��ư ȭ�� ����			
	JTabbedPane orderRightMenuPane = new JTabbedPane();
		//ġŲ�޴�
		JPanel orderTotalChickenTitlePane = new JPanel(new BorderLayout());
			JPanel orderChickenTitlePane = new JPanel();
				JLabel orderChickenLbl = new JLabel("ġŲ");
			JPanel chickenPane = new JPanel(new GridLayout(4,2,100,60));
				JButton japa = new JButton("¥��ġŲ");
				JButton ganji = new JButton("����ġŲ");
				JButton gochu = new JButton("����ġŲ");
				JButton jangs = new JButton("�彺ġŲ");
				JButton sixSeconds = new JButton("6��ġŲ");
				JButton fried = new JButton("�Ķ��̵�");
				JButton yangnyum = new JButton("���ġŲ");
				JButton backBtn = new JButton("�ڷΰ���");
			
		//�ݹ�
		JPanel orderTotalHalfPane = new JPanel(new BorderLayout());
			JPanel orderHalfPane = new JPanel();
				JLabel orderHalfLbl = new JLabel("�ݹݸ޴�");
			JPanel halfPane = new JPanel(new GridLayout(5,5,30,30));
				JButton halfjapaGochu = new JButton("¥��/����");
				JButton halfjapaGanji = new JButton("¥��/����");
				JButton halfjapaJangs = new JButton("¥��/�彺");
				JButton halfjapaSixSeconds = new JButton("¥��/6��");
				JButton halfjapaFried = new JButton("¥��/��");
				JButton halfjapaYangnyum = new JButton("¥��/���");
		
				JButton halfganjiGochu = new JButton("����/����");
				JButton halfganjiJangs = new JButton("����/�彺");
				JButton halfganjiSixSeconds = new JButton("����/6��");
				JButton halfganjiFried = new JButton("����/��");
				JButton halfganjiYangnyum = new JButton("����/���");
		
				JButton halfgochuJangs = new JButton("����/�彺");
				JButton halfgochuSixSeconds = new JButton("����/6��");
				JButton halfgochuFried = new JButton("����/��");
				JButton halfgochuYangnyum = new JButton("����/���");
		
				JButton halfjangsSixSeconds = new JButton("�彺/6��");
				JButton halfjangsFried = new JButton("�彺/�Ķ��̵�");
				JButton halfjangsYangnyum = new JButton("�彺/���");
		
				JButton halfsixSecondsFried = new JButton("6��/��");
				JButton halfsixSecondsYangnyum = new JButton("6��/���");
		
				JButton halffriedYangnyum = new JButton("��/���");
					
		//�κ���
		JPanel orderTotalSpecialPane = new JPanel(new BorderLayout());
			JPanel orderSpecialPane = new JPanel();
				JLabel orderSpecialLbl = new JLabel("�κ���");
			JPanel special = new JPanel();			
				JButton legs = new JButton("�ٸ���");
				JButton wings = new JButton("������");
		
		//����/�ַ�
		JPanel orderTotalBeveragePane = new JPanel(new BorderLayout());	
			JPanel orderBeveragepane = new JPanel();
				JLabel orderBeverageLbl = new JLabel("����/�ַ�");
			JPanel beverage = new JPanel(new GridLayout(3,3,60,60));		
				JButton cola = new JButton("�ݶ�");
				JButton fanta = new JButton("ȯŸ");
				JButton cider = new JButton("���̴�");
				JButton bottleBeer = new JButton("ī��");
				JButton draft = new JButton("������");
				JButton soju = new JButton("����");
		//���̵�
		JPanel orderTotalSidePane = new JPanel(new BorderLayout());		
			JPanel orderSidepane = new JPanel();
				JLabel orderSideLbl = new JLabel("���̵� �޴�");
				
			JPanel side = new JPanel(new GridLayout(3,3,60,60));
				JButton cheeseStick = new JButton("ġ�ƽ");
				JButton cheeseBall = new JButton("ġ�");
				JButton ddokbokki = new JButton("������");
				JButton muktae = new JButton("����");
				JButton friedDumpling = new JButton("Ƣ�踸��");
				JButton friedPepper = new JButton("����Ƣ��");
				JButton zondog = new JButton("�˵���");
				
		//��Ÿ
		JPanel orderTotalEtcPane = new JPanel(new BorderLayout());	
			JPanel orderEtcpane = new JPanel();
				JLabel orderEtcLbl = new JLabel("��Ÿ");
			JPanel etc = new JPanel(new GridLayout(2,2,60,60));
				JButton deliFee = new JButton("��޺��");
				JButton hotsouce = new JButton("�ſ�ҽ�");
				JButton addradish = new JButton("���߰�");
				JButton sizeUp = new JButton("���� �������");
	
				
				
				
				
				
//////////�ֹ���Ȳ ȭ�� ���� �޼ҵ�	
	public void menuDisplay() {	
	
		empty();
		
						
	////���� �ֹ���Ȳ â			
		
		orderTitlePane.setOpaque(true);
		orderTitlePane.setBackground(new Color(159,183,225));
		orderTitlePane.add(orderTitleLbl);	
		
		
		orderTablePane.setOpaque(true);
		orderTablePane.setBackground(Color.white);
		orderTablePane.add(orderTableLbl);	
		
		
		
		orderTableMasPane.add(orderTablePane,BorderLayout.NORTH);	
		orderTableMasPane.add(orderSp);	
		
		
		orderButton.setBackground(new Color(43,153,187));
		orderButton.setForeground(Color.white);
		orderBtnPane.setOpaque(true);
		orderBtnPane.setBackground(new Color(159,183,225));
		orderBtnPane.add(orderButton);	
								
		orderStatePane.add("North",orderTitlePane);	
		orderStatePane.add("Center",orderTableMasPane);
		orderStatePane.add("South",orderBtnPane);
		
		
	
	////���� �޴� ���� â	
		
		//ġŲ �г�
		
		
		chickenPane.add(japa);		chickenPane.add(ganji);		chickenPane.add(gochu);		chickenPane.add(jangs);		chickenPane.add(sixSeconds);
		chickenPane.add(fried);		chickenPane.add(yangnyum);	chickenPane.add(backBtn);
		
		JButton []chick = {japa,ganji,gochu,jangs,sixSeconds,fried,yangnyum,backBtn};
		for(int i=0;i<chick.length;i++) {
			chick[i].setForeground(Color.white);
			chick[i].setBackground(new Color(43,153,187));
		}
				
		orderChickenTitlePane.add(orderChickenLbl);
		orderChickenTitlePane.setOpaque(true);
		orderChickenTitlePane.setBackground(Color.white);
		
		orderTotalChickenTitlePane.add("North",orderChickenTitlePane);
		chickenPane.setBackground(Color.white);
		orderTotalChickenTitlePane.add("Center",chickenPane);
		
		
		
		//�ݹ� �г�
		
		JButton [] half = {halfjapaGochu, halfjapaGanji, halfjapaJangs, halfjapaSixSeconds, halfjapaFried, halfjapaYangnyum, halfganjiGochu, halfganjiJangs, halfganjiSixSeconds, halfganjiFried, halfganjiYangnyum,  halfgochuJangs,
							 halfgochuFried,	halfgochuYangnyum, halfjangsSixSeconds,	halfjangsFried,halfjangsYangnyum, halfsixSecondsFried, halfsixSecondsYangnyum, halffriedYangnyum};		
		
		for(int i=0;i<half.length;i++) {
			halfPane.add(half[i]);
			half[i].setBackground(new Color(43,153,187));
			half[i].setForeground(Color.white);
			}
				
		orderHalfPane.add(orderHalfLbl);
		orderHalfPane.setOpaque(true);
		orderHalfPane.setBackground(Color.white);
		
		orderTotalHalfPane.add("North",orderHalfPane);
		halfPane.setBackground(Color.white);
		orderTotalHalfPane.add("Center",halfPane);
		
			
		
		
		//�κ���
		special.add(legs);	special.add(wings);
		
		orderSpecialPane.add(orderSpecialLbl);
		orderSpecialPane.setOpaque(true);
		orderSpecialPane.setBackground(Color.white);
		
		legs.setBackground(new Color(43,153,187));
		legs.setForeground(Color.white);
		wings.setBackground(new Color(43,153,187));
		wings.setForeground(Color.white);
		
		
		orderTotalSpecialPane.add("North",orderSpecialPane);
		special.setBackground(Color.white);
		orderTotalSpecialPane.add("Center",special);
		
		
		
		
		
		
		
		//����/�ַ�
		JButton bev [] = {cola,fanta,cider,bottleBeer,draft,soju};
				
		for(int i=0;i<bev.length;i++) {
			beverage.add(bev[i]);
			bev[i].setBackground(new Color(43,153,187));
			bev[i].setForeground(Color.white);
		}
					
		orderBeveragepane.add(orderBeverageLbl);	
		orderBeveragepane.setOpaque(true);
		orderBeveragepane.setBackground(Color.white);
				
		orderTotalBeveragePane.add("North",orderBeveragepane);
		beverage.setBackground(Color.white);
		orderTotalBeveragePane.add("Center",beverage);
		
		
		
		
		
		
		//���̵�
		
		JButton sid [] = {cheeseStick,cheeseBall,ddokbokki,muktae,friedDumpling,friedPepper,zondog}; 
		for(int i=0;i<sid.length;i++) {
			side.add(sid[i]);
			sid[i].setBackground(new Color(43,153,187));
			sid[i].setForeground(Color.white);
		}
				
		orderSidepane.add(orderSideLbl);
		orderSidepane.setOpaque(true);
		orderSidepane.setBackground(Color.white);
			
		orderTotalSidePane.add("North",orderSidepane);
		side.setBackground(Color.white);
		orderTotalSidePane.add("Center",side);
		
		
		
		
		
		//��Ÿ
		JButton et [] = {deliFee,hotsouce,addradish,sizeUp}; 
		for(int i=0;i<et.length;i++) {
			etc.add(et[i]);
			et[i].setBackground(new Color(43,153,187));
			et[i].setForeground(Color.white);
		}
				
		orderEtcpane.add(orderEtcLbl);
		orderEtcpane.setOpaque(true);
		orderEtcpane.setBackground(Color.white);
				
		orderTotalEtcPane.add("North",orderEtcpane);
		etc.setBackground(Color.white);
		orderTotalEtcPane.add("Center",etc);
			
		
		
		
		//�� �޴�
		orderRightMenuPane.add("ġŲ",orderTotalChickenTitlePane);
		orderRightMenuPane.add("�ݹ�",orderTotalHalfPane);
		orderRightMenuPane.add("�κ���",orderTotalSpecialPane);
		orderRightMenuPane.add("����/�ַ�",orderTotalBeveragePane);
		
		
		orderRightMenuPane.add("���̵�",orderTotalSidePane);
		orderRightMenuPane.add("��Ÿ",orderTotalEtcPane);
		
		
		orderMasPane.add(orderStatePane);
		orderRightMenuPane.setBackground(new Color(244,177,131));
		orderMasPane.add(orderRightMenuPane);
		
		
		add("Center",orderMasPane);
	
		setSize(700,700);
		setVisible(true);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		
	}
		
		
		
		
///////////Ȧ���� �޴�	
	
	public void tableState() {
		empty();
					
		table1Lbl.setOpaque(true);
		table1Lbl.setBackground(new Color(43,153,187));	
		table1.add("North",table1Lbl);
		table1.add("Center",tableScroll1);
				
		table2Lbl.setOpaque(true);
		table2Lbl.setBackground(new Color(43,153,187));		
		table2.add("North",table2Lbl);
		table2.add("Center",tableScroll2);
		
		table3Lbl.setOpaque(true);
		table3Lbl.setBackground(new Color(43,153,187));	
		table3.add("North",table3Lbl);
		table3.add("Center",tableScroll3);
		
		table4Lbl.setOpaque(true);
		table4Lbl.setBackground(new Color(43,153,187));	
		table4.add("North",table4Lbl);
		table4.add("Center",tableScroll4);
		
		table5Lbl.setOpaque(true);
		table5Lbl.setBackground(new Color(43,153,187));	
		table5.add("North",table5Lbl);
		table5.add("Center",tableScroll5);
		
		table6Lbl.setOpaque(true);
		table6Lbl.setBackground(new Color(43,153,187));	
		table6.add("North",table6Lbl);
		table6.add("Center",tableScroll6);
		
		
		tableBackBtn.setBackground(new Color(43,153,187));
		tableBackPane.add(tableBlank1);
		tableBackPane.add(tableBlank2);
		tableBackPane.add(tableBackBtn);
		
		
		
		//���̺� �г� ����
		tablePane.add(table1);	tablePane.add(table2);	tablePane.add(table3);	tablePane.add(table4);	tablePane.add(table5);	tablePane.add(table6);
		tableMasPane.add("Center",tablePane);
		
		//���̺� �г� ����
		tableMasPane.add("South",tableBackPane);
		
		
		//������ ����
		add("Center",tableMasPane);
		
		
		setSize(800,800);
		setVisible(true);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		
		
	}
			
			
			
			
	public MainMenu() {	//���� ������ �޼ҵ� ����
		
		empty();
			
	//���� ��� Ÿ��Ʋ
		
		mainTiltPaneset.add(mainTitleLbl);
		mainTiltPaneset.setBackground(new Color(43,153,187));
		mainTitleLbl.setForeground(Color.white);
		mainTitlePane.add(mainTiltPaneset);
		
		
		mainBlankPanel.add(mainBlankLbl);
		mainBlankPanel.setBackground(new Color(216,244,248));
		mainTitlePane.add(mainBlankPanel);
			

				
		mainMasPane.add("North",mainTitlePane);
		
		//���� ���� ��ư����
		
		mainSalesBtn.setBackground(new Color(43,153,187));
		mainSalesBtn.setForeground(new Color(216,244,248));
		mainCenterPane.add(mainSalesBtn);
			
		mainStockBtn.setBackground(new Color(43,153,187));
		mainStockBtn.setForeground(new Color(216,244,248));
		mainCenterPane.add(mainStockBtn);
		
		mainSalConBtn.setBackground(new Color(43,153,187));
		mainSalConBtn.setForeground(new Color(216,244,248));
		mainCenterPane.add(mainSalConBtn);
		
		mainOffBtn.setBackground(new Color(43,153,187));
		mainOffBtn.setForeground(new Color(216,244,248));
		mainCenterPane.add(mainOffBtn);
		
		mainCenterPane.setBackground(new Color(216,244,248));
		mainMasPane.add("Center",mainCenterPane);
		
		
		
		add("Center",mainMasPane);
				
		
		setSize(800,800);
		setVisible(true);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		
		
		
		mainOffBtn.addActionListener(this);//����
		mainSalConBtn.addActionListener(this);
		mainStockBtn.addActionListener(this);
		mainSalesBtn.addActionListener(this);
		
	}

	public void actionPerformed(ActionEvent ad) {
		String mainBtn = ad.getActionCommand();
		
		if(mainBtn.equals("���α׷� ����")) {
			System.exit(0);
		}
		if(mainBtn.equals("�������")) {
			new StockMgn();
			setVisible(false);
		}if(mainBtn.equals("�����޴�")) {
			new StoreIn();
			setVisible(false);
		
		}if(mainBtn.equals("�޴��߰�")) {
			new AddMenu();
			setVisible(false);
			
		}if(mainBtn.equals("��������")) {
			setVisible(false);
			new SalesCheck();
		}
		
	}
	
	
////////�����޴� ȭ��	
	
	public void salesMenu() {
//		empty();
//					
//				
//		//���� ��� Ÿ��Ʋ
//			
//			salesTiltPaneset.add(salesTitleLbl);
//			salesTiltPaneset.setBackground(new Color(43,153,187));
//			salesTitleLbl.setForeground(Color.white);
//			salesTitlePane.add(salesTiltPaneset);
//			
//			
//			salesBlankPanel.add(salesBlankLbl);
//			salesBlankPanel.setBackground(new Color(216,244,248));
//			salesTitlePane.add(salesBlankPanel);
//				
//
//					
//			salesMasPane.add("North",salesTitlePane);
//			
//			//���� ���� ��ư����
//			
//			salesSalesBtn.setBackground(new Color(43,153,187));
//			salesSalesBtn.setForeground(new Color(216,244,248));
//			salesCenterPane.add(salesSalesBtn);
//				
//			salesStockBtn.setBackground(new Color(43,153,187));
//			salesStockBtn.setForeground(new Color(216,244,248));
//			salesCenterPane.add(salesStockBtn);
//			
//			salesSalConBtn.setBackground(new Color(43,153,187));
//			salesSalConBtn.setForeground(new Color(216,244,248));
//			salesCenterPane.add(salesSalConBtn);
//			
//			salesOffBtn.setBackground(new Color(43,153,187));
//			salesOffBtn.setForeground(new Color(216,244,248));
//			salesCenterPane.add(salesOffBtn);
//			
//			salesCenterPane.setBackground(new Color(216,244,248));
//			salesMasPane.add("Center",salesCenterPane);
//			
//			
//			
//			add("Center",salesMasPane);
//					
//			
//			setSize(800,800);
//			setVisible(true);
//			setDefaultCloseOperation(DISPOSE_ON_CLOSE);
//		
//		
		
	}
	
	
	public void empty() {
		//��� ���鿵��
				JLabel frameBlankLbl = new JLabel(" ");
					Dimension d1 = new Dimension(800,80);
					frameBlankLbl.setOpaque(true);
					frameBlankLbl.setPreferredSize(d1);
					frameBlankLbl.setBackground(new Color(216,244,248));
							
					add("North",frameBlankLbl);
							
							
				//���� ���鿵��
				JLabel frameBlankLbl2 = new JLabel(" ");
					Dimension d2 = new Dimension(120,800);
					frameBlankLbl2.setOpaque(true);
					frameBlankLbl2.setPreferredSize(d2);
					frameBlankLbl2.setBackground(new Color(216,244,248));
							
					add("West",frameBlankLbl2);
											
				//���� ���鿵��
					JLabel frameBlankLbl3 = new JLabel(" ");
						Dimension d3 = new Dimension(120,800);
						frameBlankLbl3.setOpaque(true);
						frameBlankLbl3.setPreferredSize(d3);
						frameBlankLbl3.setBackground(new Color(216,244,248));
							
						add("East",frameBlankLbl3);
							
				//�ϴ� ���鿵��
					JLabel frameBlankLbl4 = new JLabel(" ");
						Dimension d4 = new Dimension(800,80);
						frameBlankLbl4.setOpaque(true);
						frameBlankLbl4.setPreferredSize(d4);
						frameBlankLbl4.setBackground(new Color(216,244,248));
									
						add("South",frameBlankLbl4);
				}
		
	
	
	

	
	
	
	public static void main(String[] args) {
		new MainMenu();

	}

}
