import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class IdMenu extends JFrame{

	
	
	JPanel masPane = new JPanel(new BorderLayout());
	//�����߰� ��� Ÿ��Ʋ ����
		JPanel addIdPane = new JPanel();
			JLabel addIdLbl = new JLabel("�����߰� �޴�");
	//�����߰� ���� �� ����
		JPanel addleftPane = new JPanel(new GridLayout(3,1));
			JLabel addleftnameLbl = new JLabel("�̸�");
			JLabel addleftIdLbl = new JLabel("���̵�");
			JLabel addleftPwLbl = new JLabel("��й�ȣ ");
	
	//�����߰� ���� �ؽ�Ʈ�ڽ� ����
		JPanel addCenterPane = new JPanel(new GridLayout(3,1));	
			JTextField centerNameBox = new JTextField();
			JTextField centerIdBox = new JTextField();
			JTextField centerPwBox = new JTextField();
		
	//�����߰� ���� �ߺ��˻� ����
		JPanel addRightPane = new JPanel(new GridLayout(3,1));
			JLabel addblankLbl = new JLabel(" ");
			JButton adddupBtn = new JButton("�ߺ��˻�");
			JLabel addblackLbl2 = new JLabel(" ");
	
	//�����߰� �ϴ� ��ư ����
		JPanel addBottomPane = new JPanel();
			JButton addIdBtn = new JButton("�����߰�");
			JButton addbackBtn = new JButton("�ڷΰ���");
	///////////////////////////////////////////
		
			
			
			
			
			//����ã�� ����
			JPanel fndmasPane = new JPanel(new BorderLayout());
			//����ã�� ��� Ÿ��Ʋ ����
				JPanel fndIdPane = new JPanel();
					JLabel fndIdLbl = new JLabel("����ã�� �޴�");
			//����ã�� ���� �� ����
				JPanel fndleftPane = new JPanel(new GridLayout(4,1));
					JLabel fndleftnameLbl = new JLabel("�̸�");
					JLabel fndleftIdLbl = new JLabel("���̵�");
					JLabel fndleftPwLbl = new JLabel("��й�ȣ ");
					
					
			//����ã�� ���� �ؽ�Ʈ�ڽ� ����
				JPanel fndCenterPane = new JPanel(new GridLayout(4,1));	
					JTextField fndcenterNameBox = new JTextField();
					JTextField fndcenterIdBox = new JTextField();
					JTextField fndcenterPwBox = new JTextField();
									
					
						
			//����ã�� ���� �ߺ��˻� ����
				JPanel fndRightPane = new JPanel(new GridLayout(5,1));
					JLabel fndblankLb3 = new JLabel("");			JPanel tp1 = new JPanel(new FlowLayout(FlowLayout.LEFT)); 
					JLabel fndblankLb4 = new JLabel("");			JPanel tp2 = new JPanel();
					JButton fnddupBtn = new JButton("�ߺ��˻�");	JPanel tp3 = new JPanel();
					JLabel fndblackLbl5 = new JLabel("");		JPanel tp4 = new JPanel();
					JLabel fndblackLbl6 = new JLabel("");		JPanel tp5 = new JPanel();
					
			//����ã�� �ϴ� ��ư ����
				JPanel fndBottomPane = new JPanel();
					JLabel fndBlankLbl = new JLabel("                             ");
					JButton fndIdBtn = new JButton("Ȯ��");
					JButton fndbackBtn = new JButton("�ڷΰ���");
			
				

			
	//////////////////////////////////////////		
	//�������� ȭ�鿵��
	JPanel revisemasPane = new JPanel(new BorderLayout());
	//�������� ��� Ÿ��Ʋ ����
		JPanel reviseIdPane = new JPanel();
			JLabel reviseIdLbl = new JLabel("�������� �޴�");
	//�������� ���� �� ����
		JPanel reviseleftPane = new JPanel(new GridLayout(5,1));
			JLabel reviseleftnameLbl = new JLabel("�̸�");
			JLabel reviseleftIdLbl = new JLabel("���̵�");
			JLabel reviseleftPwLbl = new JLabel("��й�ȣ ");
			JLabel reviseleftnewIdLbl = new JLabel("���� ���̵�");
			JLabel reviseleftnewPwLbl = new JLabel("���� ��й�ȣ");
			
	//�������� ���� �ؽ�Ʈ�ڽ� ����
		JPanel reviseCenterPane = new JPanel(new GridLayout(5,1));	
			JTextField revisecenterNameBox = new JTextField();
			JTextField revisecenterIdBox = new JTextField();
			JTextField revisecenterPwBox = new JTextField();
			JTextField revisecenternewIdBox = new JTextField();
			JTextField revisecenternewPwBox = new JTextField();
			
			
				
	//�������� ���� �ߺ��˻� ����
		JPanel reviseRightPane = new JPanel(new GridLayout(5,1));
			JLabel reviseblankLb3 = new JLabel("");			JPanel jp1 = new JPanel(); 
			JLabel reviseblankLb4 = new JLabel("");			JPanel jp2 = new JPanel();
			JButton revisedupBtn = new JButton("�ߺ��˻�");	JPanel jp3 = new JPanel();
			JLabel reviseblackLbl5 = new JLabel("");		JPanel jp4 = new JPanel();
			JLabel reviseblackLbl6 = new JLabel("");		JPanel jp5 = new JPanel();
			
	//�������� �ϴ� ��ư ����
		JPanel reviseBottomPane = new JPanel();
			JLabel reviseBlankLbl = new JLabel("                             ");
			JButton reviseIdBtn = new JButton("Ȯ��");
			JButton revisebackBtn = new JButton("�ڷΰ���");
	///////////////////////////////////////////////////////////////////////////		

			
			
	
			
			
	public IdMenu() {}
		
	
	public void backBtn() {
	//�ڷΰ����ư	
			
	}
	
	
	/*public void findId() {
		empty();
		
		
		fndLblpane.add(fndTitleLbl);		
		fndTitlePane.add("North",fndLblpane);
		fndTitlePane.add("South",fndBlank);	
		
		
		fndLpane.add(fndName);
		fndLpane.add(fndId);
		fndLpane.add(fndPwd);
		fndLpane.add(fndQues);
		
		fndMidpane.add("West",fndLpane);
		
		fndBpane.add(fndconBtn);
		fndBpane.add(fndbacBtn);
		
		
		fndMaspane.add("North",fndTitlePane);
		fndMaspane.add("Center",fndMidpane);
		fndMaspane.add("South",fndBpane);
		
		
		add("Center",fndMaspane);
		
		
		setSize(800,600);
		setVisible(true);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		
	}*/
	
	
	
	public void findId() {
		empty();
				
		//���� ��� Ÿ��Ʋ �г�
		fndIdPane.setOpaque(true);
		fndIdPane.setBackground(new Color(43,153,187));
		fndIdLbl.setForeground(Color.white);
		fndIdPane.add(fndIdLbl);
		fndmasPane.add("North",fndIdPane);		
		
		//���� ���� �� ����
		fndleftPane.add(fndleftnameLbl);		fndleftPane.add(fndleftIdLbl);		fndleftPane.add(fndleftPwLbl);	
		fndleftPane.setOpaque(true);
		fndleftPane.setBackground(new Color(216,244,248));
		fndmasPane.add("West",fndleftPane);
		
		//���� �߾� �ؽ�Ʈ�ڽ� ����
		fndCenterPane.add(fndcenterNameBox);	fndCenterPane.add(fndcenterIdBox);		fndCenterPane.add(fndcenterPwBox);
		fndmasPane.add("Center",fndCenterPane);
		
		//���� ���� �ߺ��˻� ��ư ����
		tp1.setOpaque(true);
		tp1.setBackground(new Color(216,244,248));
		
		
		tp2.setOpaque(true);
		tp2.setBackground(new Color(216,244,248));
		
		
		tp3.setOpaque(true);
		tp3.setBackground(new Color(216,244,248));
		fnddupBtn.setBackground(new Color(43,153,187));
		fnddupBtn.setForeground(Color.white);
		
		
		
		
		//jp4.add(revisedupBtn);		addRightPane.add(jp4);	 
		//jp5.add(reviseblackLbl6);		addRightPane.add(jp5);	 
		fndmasPane.add("East",addRightPane);
		
		
		//�ϴ� ��ư ����
		
		fndBottomPane.setOpaque(true);
		fndBottomPane.setBackground(new Color(216,244,248));
		
		Dimension nd2 = new Dimension(120,80);
		fndIdBtn.setPreferredSize(nd2);
		fndIdBtn.setBackground(new Color(43,153,187));
		fndIdBtn.setForeground(Color.white);
		fndBottomPane.add(fndIdBtn);
		
		
		
		fndBottomPane.add(fndBlankLbl);
		
				
		Dimension nd3 = new Dimension(120,80);
		fndbackBtn.setPreferredSize(nd3);
		fndbackBtn.setBackground(new Color(43,153,187));
		fndbackBtn.setForeground(Color.white);
		fndBottomPane.add(fndbackBtn);
		
		
		
		fndmasPane.add("South",fndBottomPane);
				
				
		add("Center",fndmasPane);				
	
		setSize(700,500);
		setVisible(true);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);	
		
	}
	
	
	
	
	
	
	
	
	
	public void revise() {
		empty();
				
		//���� ��� Ÿ��Ʋ �г�
		reviseIdPane.setOpaque(true);
		reviseIdPane.setBackground(new Color(43,153,187));
		reviseIdLbl.setForeground(Color.white);
		reviseIdPane.add(reviseIdLbl);
		revisemasPane.add("North",reviseIdPane);		
		
		//���� ���� �� ����
		reviseleftPane.add(reviseleftnameLbl);		reviseleftPane.add(reviseleftIdLbl);		reviseleftPane.add(reviseleftPwLbl);	reviseleftPane.add(reviseleftnewIdLbl);	reviseleftPane.add(reviseleftnewPwLbl);
		reviseleftPane.setOpaque(true);
		reviseleftPane.setBackground(new Color(216,244,248));
		revisemasPane.add("West",reviseleftPane);
		
		//���� �߾� �ؽ�Ʈ�ڽ� ����
		reviseCenterPane.add(revisecenterNameBox);	reviseCenterPane.add(revisecenterIdBox);		reviseCenterPane.add(revisecenterPwBox);	reviseCenterPane.add(revisecenternewIdBox);	reviseCenterPane.add(revisecenternewPwBox);
		revisemasPane.add("Center",reviseCenterPane);
		
		//���� ���� �ߺ��˻� ��ư ����
		jp1.setOpaque(true);
		jp1.setBackground(new Color(216,244,248));
		jp1.add(reviseblankLb3);	    addRightPane.add(jp1);	
		
		jp2.setOpaque(true);
		jp2.setBackground(new Color(216,244,248));
		jp2.add(reviseblankLb4);		addRightPane.add(jp2);	 
		
		jp3.setOpaque(true);
		jp3.setBackground(new Color(216,244,248));
		revisedupBtn.setBackground(new Color(43,153,187));
		revisedupBtn.setForeground(Color.white);
		jp3.add(revisedupBtn);			addRightPane.add(jp3);	
		
		
		
		//jp4.add(revisedupBtn);		addRightPane.add(jp4);	 
		//jp5.add(reviseblackLbl6);		addRightPane.add(jp5);	 
		revisemasPane.add("East",addRightPane);
		
		
		//�ϴ� ��ư ����
		
		reviseBottomPane.setOpaque(true);
		reviseBottomPane.setBackground(new Color(216,244,248));
		
		Dimension nd2 = new Dimension(120,80);
		reviseIdBtn.setPreferredSize(nd2);
		reviseIdBtn.setBackground(new Color(43,153,187));
		reviseIdBtn.setForeground(Color.white);
		reviseBottomPane.add(reviseIdBtn);
		
		
		
		reviseBottomPane.add(reviseBlankLbl);
		
				
		Dimension nd3 = new Dimension(120,80);
		revisebackBtn.setPreferredSize(nd3);
		revisebackBtn.setBackground(new Color(43,153,187));
		revisebackBtn.setForeground(Color.white);
		reviseBottomPane.add(revisebackBtn);
		
		
		
		revisemasPane.add("South",reviseBottomPane);
				
				
		add("Center",revisemasPane);				
	
		setSize(700,500);
		setVisible(true);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);	
		
	}
	
	

	
	
	
		
	public void addId(){
		empty();
				
		//���� ��� Ÿ��Ʋ �г�
		addIdPane.add(addIdLbl);
		addIdPane.setOpaque(true);
		addIdPane.setBackground(new Color(43,153,187));
		addIdLbl.setForeground(Color.white);		
		
				
		//���� �������г� ����
		masPane.add("North",addIdPane);		
		//���� ���� �� ����
		addleftPane.setBackground(new Color(216,244,248));
		addleftPane.add(addleftnameLbl);		addleftPane.add(addleftIdLbl);		addleftPane.add(addleftPwLbl);
		masPane.add("West",addleftPane);
		
		
		
		
		//���� �߾� �ؽ�Ʈ�ڽ� ����
		addCenterPane.add(centerNameBox);	addCenterPane.add(centerIdBox);		addCenterPane.add(centerPwBox);
		masPane.add("Center",addCenterPane);
		
		//���� ���� �ߺ��˻� ��ư ����
		addRightPane.add(addblankLbl);	 addRightPane.add(adddupBtn);	 addRightPane.add(addblackLbl2);
		addRightPane.setBackground(new Color(216,244,248));
		adddupBtn.setBackground(new Color(43,153,187));
		adddupBtn.setForeground(Color.white);
		
		
		masPane.add("East",addRightPane);
		
		
		//�ϴ� ��ư ����
		addBottomPane.add(addIdBtn);	addBottomPane.add(addbackBtn);
		addBottomPane.setBackground(new Color(216,244,248));
		addIdBtn.setBackground(new Color(43,153,187));
		addIdBtn.setForeground(Color.white);
		
		
		addbackBtn.setBackground(new Color(43,153,187));
		addbackBtn.setForeground(Color.white);
		
		
		
		masPane.add("South",addBottomPane);
								
		add("Center",masPane);
						
						
		setSize(700,500);
		setVisible(true);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		
	}

	public void empty() {
		//��� ���鿵��
				JLabel frameBlankLbl = new JLabel(" ");
					Dimension d1 = new Dimension(800,80);
					frameBlankLbl.setOpaque(true);
					frameBlankLbl.setPreferredSize(d1);
					frameBlankLbl.setBackground(new Color(216,244,248));
							
					add("North",frameBlankLbl);
							
							
				//���� ���鿵��
				JLabel frameBlankLbl2 = new JLabel(" ");
					Dimension d2 = new Dimension(120,800);
					frameBlankLbl2.setOpaque(true);
					frameBlankLbl2.setPreferredSize(d2);
					frameBlankLbl2.setBackground(new Color(216,244,248));
							
					add("West",frameBlankLbl2);
											
				//���� ���鿵��
					JLabel frameBlankLbl3 = new JLabel(" ");
						Dimension d3 = new Dimension(120,800);
						frameBlankLbl3.setOpaque(true);
						frameBlankLbl3.setPreferredSize(d3);
						frameBlankLbl3.setBackground(new Color(216,244,248));
							
						add("East",frameBlankLbl3);
							
				//�ϴ� ���鿵��
					JLabel frameBlankLbl4 = new JLabel(" ");
						Dimension d4 = new Dimension(800,80);
						frameBlankLbl4.setOpaque(true);
						frameBlankLbl4.setPreferredSize(d4);
						frameBlankLbl4.setBackground(new Color(216,244,248));
									
						add("South",frameBlankLbl4);
				}
		
	
	
	
	
	
	
	public static void main(String[] args) {
		//�ӽ÷� ���κ� Ȱ��
		new IdMenu();

	}

}
