import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class StockMgn extends JFrame implements ActionListener{

	//��Ż �г�
	JPanel absolutePane = new JPanel(new BorderLayout());
	//��� ������ �г�
	JPanel stMasPane1 = new JPanel(new BorderLayout());
	
	//��� Ÿ��Ʋ �ڽ�����
	JPanel stockPane = new JPanel();
		JPanel stLbl = new JPanel();
		JLabel stocktitle = new JLabel("�������ȭ��");
		JPanel stRbl = new JPanel();
	
		
	//�ߴ� �Է¿���
	JPanel stockMpane = new JPanel();
		JPanel stockLPane = new JPanel(new GridLayout(6,1));
			JLabel stockIng = new JLabel("����");
			JLabel stockQua = new JLabel("����");
			JLabel stockPla = new JLabel("����ó");
			JLabel stockInd = new JLabel("�԰���");
			JLabel stockDda = new JLabel("�������");
			JLabel stockRem = new JLabel("���");
		JPanel inputPane = new JPanel(new GridLayout(6,1));
			JTextField inputIng = new JTextField(40);		JPanel j1 = new JPanel(new FlowLayout(FlowLayout.LEFT));
			JTextField inputQua = new JTextField(30);	JPanel j2 = new JPanel(new FlowLayout(FlowLayout.LEFT));
			JTextField inputPla = new JTextField(40);		JPanel j3 = new JPanel(new FlowLayout(FlowLayout.LEFT));
			JTextField inputInd = new JTextField(30);		JPanel j4 = new JPanel(new FlowLayout(FlowLayout.LEFT));
			JTextField inputDda = new JTextField(20);	JPanel j5 = new JPanel(new FlowLayout(FlowLayout.LEFT));
			JTextField inputRem = new JTextField(20);	JPanel j6 = new JPanel(new FlowLayout(FlowLayout.LEFT));
	
			
			
	//�ϴ� ������ �г�
	JPanel stMasPane2 = new JPanel(new BorderLayout());		
	//�ߴ� ��ư����
	JPanel stockBpane = new JPanel();
		JButton stAddBtn = new JButton("�߰�");
		JButton stRevBtn = new JButton("����");
		JButton stDelBtn = new JButton("����");
		JButton stClearBtn = new JButton("�����");
		JButton stBackBtn = new JButton("�ڷΰ���");
		
		
		
	//�ϴ� ���̺� ����
	String title [] = {"No","����","����","����ó","�԰���","�������","���"};	
	DefaultTableModel stModel = new DefaultTableModel(title,0);
	JTable stockTable = new JTable(stModel);
	JScrollPane stockBttn = new JScrollPane(stockTable);
		
		
	
	public StockMgn() {
		start();
	}
		
	public void start() {
		empty();
		//��� ������� �Է¹ڽ�����
//		Dimension stD1 = new Dimension(50,30);
//		stLbl.setPreferredSize(stD1);
		
		//stockPane.add(stLbl);
		stockPane.add(stocktitle);	
		//stockPane.add(stRbl);
		stockPane.setOpaque(true);
		stockPane.setBackground(new Color(43,153,187));
		
		
		
		//�ߴ� ���� �� 
		stockLPane.add(stockIng);
		stockLPane.add(stockQua);
		stockLPane.add(stockPla);
		stockLPane.add(stockInd);
		stockLPane.add(stockDda);
		stockLPane.add(stockRem);
		
		//�ߴ� �ؽ�Ʈ�ڽ�
		j1.add(inputIng); inputPane.add(j1);
		j2.add(inputQua); inputPane.add(j2);
		j3.add(inputPla); inputPane.add(j3);
		j4.add(inputInd); inputPane.add(j4);
		j5.add(inputDda); inputPane.add(j5);
		j6.add(inputRem); inputPane.add(j6);
				
		stMasPane1.add("North",stockPane);	
		stMasPane1.add("West",stockLPane);
		stMasPane1.add("Center",inputPane);
		
			
		
		
		//�ϴ� ��ư�������� ���̺�����..
		stockBpane.add(stAddBtn);
		stockBpane.add(stRevBtn);
		stockBpane.add(stDelBtn); 
		stockBpane.add(stClearBtn);
		stockBpane.add(stBackBtn);
			
		stMasPane2.add("North",stockBpane);
		stMasPane2.add("Center",stockBttn);
		
		
		absolutePane.add("North",stMasPane1);
		absolutePane.add(stMasPane2);
		
		
		add(absolutePane);
		
		
		
		setSize(1100,800);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setVisible(true);
		
		//��ü���ڵ� �߰�
		getAllRecord();
		
			
		stockTable.addMouseListener(new MouseAdapter() {
			public void mouseReleased(MouseEvent me) {
				if(me.getButton()==1) {
					int row=stockTable.getSelectedRow();
					inputIng.setText((String)stModel.getValueAt(row,0));  
					inputQua.setText(String.valueOf((Integer)stModel.getValueAt(row,1)));
					inputPla.setText((String)stModel.getValueAt(row,2)); 
					inputInd.setText((String)stModel.getValueAt(row,3)); 
					inputDda.setText((String)stModel.getValueAt(row,4)); 
					inputRem.setText((String)stModel.getValueAt(row,5)); 
					
				}
				
			}
					
		});
		
		stAddBtn.addActionListener(this);
		stRevBtn.addActionListener(this);
		stDelBtn.addActionListener(this);
		stClearBtn.addActionListener(this);
		stBackBtn.addActionListener(this);
		
		
		
	}
	
	
	
	public void getAllRecord() {
		//stModel.setRowCount(0);
		
			StockDAO dao =  StockDAO.getInstance();
			List<StockVo>list = dao.getAllStock();
		for(int i=0; i<list.size();i++) {
			StockVo vo = list.get(i);
			Object[] record = {vo.getIngname(),vo.getCount(), vo.getBuyplace(),vo.getWhdate(),vo.getUsdate(),vo.getRemark()};
			stModel.addRow(record);
		}
			
	}
	
	public void formClear() {
		inputIng.setText(""); 
		inputQua.setText(""); 
		inputPla.setText("");
		inputInd.setText("");
		inputDda.setText("");
		inputRem.setText("");
	}
	public void stockInsert() {
		StockVo vo = new StockVo();
		vo.setIngname(inputIng.getText());
		vo.setCount(Integer.parseInt(inputQua.getText()));
		vo.setBuyplace(inputPla.getText());
		vo.setWhdate(inputInd.getText());
		vo.setUsdate(inputDda.getText());
		vo.setRemark(inputRem.getText());
		
		if(vo.getIngname()==null || vo.getIngname().equals("")) {
			JOptionPane.showInternalMessageDialog(this, "������ �Է��ϼ���...");
		}else if(vo.getCount()==0) {
			JOptionPane.showInternalMessageDialog(this, "������ �Է��ϼ���...");
		}else if(vo.getWhdate()==null || vo.getWhdate().equals("")) {
			JOptionPane.showInternalMessageDialog(this,"�԰����� �Է��ϼ���..");
		}else if(vo.getUsdate()==null || vo.getUsdate().equals("")) {
			JOptionPane.showInternalMessageDialog(this, "��������� �Է��ϼ���");
		}else {
			StockDAO dao = new StockDAO();
			int result = dao.insertRecord(vo);
			if(result>0) {	//���ڵ尡 �߰��Ǿ�����
				JOptionPane.showInternalMessageDialog(this, "��ᰡ ��ϵǾ����ϴ�.");
				getAllRecord();
				formClear();
			}else {
				JOptionPane.showMessageDialog(this, "����Ͽ� �����߽��ϴ�.");
			}
			
		}
			
	}
	
	public void stockEdit() {
		StockVo vo = new StockVo();
		vo.setIngname(inputIng.getText());
		vo.setCount(Integer.parseInt(inputQua.getText()));
		vo.setBuyplace(inputPla.getText());
		vo.setWhdate(inputInd.getText());
		vo.setUsdate(inputDda.getText());
		vo.setRemark(inputRem.getText());
	
		if(vo.getIngname()==null || vo.getIngname().equals("")) {
			JOptionPane.showInternalMessageDialog(this, "������ �ݵ�� �־�� �մϴ�.");
			
		}else if(vo.getCount()== 0){
			JOptionPane.showInternalMessageDialog(this,"������ �ݵ�� �־�� �մϴ�.");
			
		}else if(vo.getWhdate()==null || vo.getWhdate().equals("")) {
			JOptionPane.showInternalMessageDialog(this, "�԰����� �ݵ�� �־�� �մϴ�.");
		}else if(vo.getUsdate()==null || vo.getUsdate().equals("")) {
			JOptionPane.showInternalMessageDialog(this, "��������� �ݵ�� �־�� �մϴ�.");
			
		}else {
			JOptionPane.showInternalMessageDialog(this, "������� ������ �����߽��ϴ�.");
		}
		
		
	}
	
	
	

	public void actionPerformed(ActionEvent ae) {
		Object event = ae.getSource();
		if(event == stAddBtn) {
			 stockInsert();   
		}else if(event == stRevBtn) {
			stockEdit();
		}else if(event == stDelBtn) {
			//stockDelete();
		}else if(event == stClearBtn) {
			formClear();
		}else if(event == stBackBtn) {
			setVisible(false);
			new MainMenu();
		}
			
	}
		
	
	public void empty() {
		//��� ���鿵��
				JLabel frameBlankLbl = new JLabel(" ");
					Dimension d1 = new Dimension(800,80);
					frameBlankLbl.setOpaque(true);
					frameBlankLbl.setPreferredSize(d1);
					frameBlankLbl.setBackground(new Color(216,244,248));
							
					add("North",frameBlankLbl);
							
							
				//���� ���鿵��
				JLabel frameBlankLbl2 = new JLabel(" ");
					Dimension d2 = new Dimension(120,800);
					frameBlankLbl2.setOpaque(true);
					frameBlankLbl2.setPreferredSize(d2);
					frameBlankLbl2.setBackground(new Color(216,244,248));
							
					add("West",frameBlankLbl2);
											
				//���� ���鿵��
					JLabel frameBlankLbl3 = new JLabel(" ");
						Dimension d3 = new Dimension(120,800);
						frameBlankLbl3.setOpaque(true);
						frameBlankLbl3.setPreferredSize(d3);
						frameBlankLbl3.setBackground(new Color(216,244,248));
							
						add("East",frameBlankLbl3);
							
				//�ϴ� ���鿵��
					JLabel frameBlankLbl4 = new JLabel(" ");
						Dimension d4 = new Dimension(800,80);
						frameBlankLbl4.setOpaque(true);
						frameBlankLbl4.setPreferredSize(d4);
						frameBlankLbl4.setBackground(new Color(216,244,248));
									
						add("South",frameBlankLbl4);
				}
		

	
	
	
	
	
	public static void main(String[] args) {
		new StockMgn();

	}

}
