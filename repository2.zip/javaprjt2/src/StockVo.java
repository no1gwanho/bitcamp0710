
public class StockVo {
	private String ingname;	//����
	private int count;	//����	
	private String buyplace; //����ó
	private String whdate; //�԰���
	private String usdate;	//�������
	private String remark; //���
	
	
	//�⺻������
	public StockVo() {}
	
	//���ڰ� 6��
	public StockVo(String ingname, int count, String buyplace,String whdate, String usdate, String remark) {
		
		this.ingname = ingname;
		this.count = count;
		this.buyplace = buyplace;
		this.whdate = whdate;
		this.usdate = usdate;
		this.remark = remark;
	}
	

	
		
	
	
	public String getIngname() {
		return ingname;
	}
	public void setIngname(String ingname) {
		this.ingname = ingname;
	}


	
	
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}

	
	

	public String getBuyplace() {
		return buyplace;
	}
	public void setBuyplace(String buyplace) {
		this.buyplace = buyplace;
	}

	
	

	public String getWhdate() {
		return whdate;
	}
	public void setWhdate(String whdate) {
		this.whdate = whdate;
	}

	
	

	public String getUsdate() {
		return usdate;
	}
	public void setUsdate(String usdate) {
		this.usdate = usdate;
	}

	
	
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	
	

	
	
	
	
}

