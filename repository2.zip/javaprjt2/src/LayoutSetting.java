import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class LayoutSetting extends JFrame{

	
	public LayoutSetting() {}

	
	public void mainFrameBlank() {
		JLabel frameBlankLbl = new JLabel(" ");
		Dimension d1 = new Dimension(800,80);
		frameBlankLbl.setOpaque(true);
		frameBlankLbl.setPreferredSize(d1);
		frameBlankLbl.setBackground(new Color(216,244,248));
				
		add("North",frameBlankLbl);
				
				
	//���� ���鿵��
	JLabel frameBlankLbl2 = new JLabel(" ");
		Dimension d2 = new Dimension(120,800);
		frameBlankLbl2.setOpaque(true);
		frameBlankLbl2.setPreferredSize(d2);
		frameBlankLbl2.setBackground(new Color(216,244,248));
				
		add("West",frameBlankLbl2);
								
	//���� ���鿵��
		JLabel frameBlankLbl3 = new JLabel(" ");
			Dimension d3 = new Dimension(120,800);
			frameBlankLbl3.setOpaque(true);
			frameBlankLbl3.setPreferredSize(d3);
			frameBlankLbl3.setBackground(new Color(216,244,248));
				
			add("East",frameBlankLbl3);
				
	//�ϴ� ���鿵��
		JLabel frameBlankLbl4 = new JLabel(" ");
			Dimension d4 = new Dimension(800,80);
			frameBlankLbl4.setOpaque(true);
			frameBlankLbl4.setPreferredSize(d4);
			frameBlankLbl4.setBackground(new Color(216,244,248));
						
			add("South",frameBlankLbl4);
		
	}
	
	
	public void innerBlank1() {
		
		
		
		
	}
	
	
	
}
