
public class IdVo {
	private String id;	//���̵�
	private String pw;	//�н�����	
	private String name; //�̸�
	private String idquery; //����ã�� �亯
		
	
	//�⺻������
	public IdVo() {}
	
	//�Ű����� 4��¥��
	public IdVo(String id, String pw, String name,String idquery) {
		
		this.id = id;
		this.pw = pw;
		this.name = name;
		this.idquery = idquery;
	}
	//�Ű����� 2��¥��
	public IdVo(String id, String pw) {
		this.id=id;
		this.pw=pw;
		
	}

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}

	
	
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}

	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	
	
	public String getIdquery() {
		return idquery;
	}
	public void setIdquery(String idquery) {
		this.idquery = idquery;
	}
	
	
}

