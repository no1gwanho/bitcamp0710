import java.util.ArrayList;
import java.util.List;

public class StockDAO extends DBCon{

	
	
	public StockDAO() {
		
	}

	public static StockDAO getInstance() {
		return new StockDAO();
		
	}
	
	//���ڵ� �߰�
	public int insertRecord(StockVo vo) {
		int result = 0;
		try {
			getConn();
			
			String sql = "insert into ingredients(ingname, count, buyplace, whdate, usdate, remark)";                    
		
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, vo.getIngname());
			pstmt.setInt(2, vo.getCount());
			pstmt.setString(3, vo.getBuyplace());
			pstmt.setString(4, vo.getWhdate());
			pstmt.setString(5, vo.getUsdate());
			pstmt.setString(6, vo.getRemark());
			
			result = pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			getClose();
		}
		return result;
	}
	
	//���ڵ� ����
	public int updateRecord(StockVo vo) {
		int result=0;
		try {
			getConn();
			String sql = "update ingredients set ingname=?,count=?,buyplace=?,whdate=?,usdate=?,remark=?";
			
		}catch(Exception e) {
					
		}finally {
			getClose();
			
		}
		return result;
					
	}
	
	
	
	public List<StockVo> getAllStock(){
		
		List<StockVo> list = new ArrayList<StockVo>();
		try {
			getConn();
			
			//select�� ����~
			String sql="select ingname, count, buyplace,whdate,usdate,remark from ingredients";
			pstmt = conn.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
			//6�� Vo���� ���� �����ͺ��̽��� ��������
			StockVo vo = new StockVo(rs.getString(1),rs.getInt(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getNString(6));
			list.add(vo);
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			getClose();
		}
		return list;
	}
	
		
	
}
