import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class StoreTable extends JFrame implements ActionListener{

	//Ȧ ���� �޴�  ���̺� ����
	
		JPanel tableMasPane = new JPanel(new BorderLayout());
			JPanel tablePane = new JPanel(new GridLayout(2,3,30,20));			
				
				JPanel table1 = new JPanel(new BorderLayout());
					JLabel table1Lbl = new JLabel("Table1");
					JTextArea tableBox1 = new JTextArea();	
					JScrollPane tableScroll1 = new JScrollPane(tableBox1);
		
				JPanel table2 = new JPanel(new BorderLayout());
					JLabel table2Lbl = new JLabel("Table2");
					JTextArea tableBox2 = new JTextArea();
					JScrollPane tableScroll2 = new JScrollPane(tableBox2);
		
				JPanel table3 = new JPanel(new BorderLayout());
					JLabel table3Lbl = new JLabel("Table3");
					JTextArea tableBox3 = new JTextArea();
					JScrollPane tableScroll3 = new JScrollPane(tableBox3);
		
				JPanel table4 = new JPanel(new BorderLayout());
					JLabel table4Lbl = new JLabel("Table4");
					JTextArea tableBox4 = new JTextArea();
					JScrollPane tableScroll4 = new JScrollPane(tableBox4);
			
				JPanel table5 = new JPanel(new BorderLayout());
					JLabel table5Lbl = new JLabel("Table5");
					JTextArea tableBox5 = new JTextArea();
					JScrollPane tableScroll5 = new JScrollPane(tableBox5);
		
				
				JPanel table6 = new JPanel(new BorderLayout());
					JLabel table6Lbl = new JLabel("Table6");
					JTextArea tableBox6 = new JTextArea();
					JScrollPane tableScroll6 = new JScrollPane(tableBox6);
			
			JPanel tableBackPane = new JPanel(new GridLayout(1,3,30,20));
				JLabel tableBlank1 = new JLabel("");
				JLabel tableBlank2 = new JLabel("");
				JButton tableBackBtn = new JButton("�ڷΰ���");
		//////////////////////////////////////////////////////////////////////////////
				
	
	public StoreTable() {
		tableState();
		
	}
	
		
		public void tableState() {
			empty();
						
			table1Lbl.setOpaque(true);
			table1Lbl.setBackground(new Color(43,153,187));	
			table1.add("North",table1Lbl);
			table1.add("Center",tableScroll1);
					
			table2Lbl.setOpaque(true);
			table2Lbl.setBackground(new Color(43,153,187));		
			table2.add("North",table2Lbl);
			table2.add("Center",tableScroll2);
			
			table3Lbl.setOpaque(true);
			table3Lbl.setBackground(new Color(43,153,187));	
			table3.add("North",table3Lbl);
			table3.add("Center",tableScroll3);
			
			table4Lbl.setOpaque(true);
			table4Lbl.setBackground(new Color(43,153,187));	
			table4.add("North",table4Lbl);
			table4.add("Center",tableScroll4);
			
			table5Lbl.setOpaque(true);
			table5Lbl.setBackground(new Color(43,153,187));	
			table5.add("North",table5Lbl);
			table5.add("Center",tableScroll5);
			
			table6Lbl.setOpaque(true);
			table6Lbl.setBackground(new Color(43,153,187));	
			table6.add("North",table6Lbl);
			table6.add("Center",tableScroll6);
			
			
			tableBackBtn.setBackground(new Color(43,153,187));
			tableBackPane.add(tableBlank1);
			tableBackPane.add(tableBlank2);
			tableBackPane.add(tableBackBtn);
			
			
			
			//���̺� �г� ����
			tablePane.add(table1);	tablePane.add(table2);	tablePane.add(table3);	tablePane.add(table4);	tablePane.add(table5);	tablePane.add(table6);
			tableMasPane.add("Center",tablePane);
			
			//���̺� �г� ����
			tableMasPane.add("South",tableBackPane);
			
			
			//������ ����
			add("Center",tableMasPane);
			
			
			setSize(800,800);
			setVisible(true);
			setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			
			
			
			tableBackBtn.addActionListener(this);
			
		}	
		
		public void empty() {
			//��� ���鿵��
					JLabel frameBlankLbl = new JLabel(" ");
						Dimension d1 = new Dimension(800,80);
						frameBlankLbl.setOpaque(true);
						frameBlankLbl.setPreferredSize(d1);
						frameBlankLbl.setBackground(new Color(216,244,248));
								
						add("North",frameBlankLbl);
								
								
					//���� ���鿵��
					JLabel frameBlankLbl2 = new JLabel(" ");
						Dimension d2 = new Dimension(120,800);
						frameBlankLbl2.setOpaque(true);
						frameBlankLbl2.setPreferredSize(d2);
						frameBlankLbl2.setBackground(new Color(216,244,248));
								
						add("West",frameBlankLbl2);
												
					//���� ���鿵��
						JLabel frameBlankLbl3 = new JLabel(" ");
							Dimension d3 = new Dimension(120,800);
							frameBlankLbl3.setOpaque(true);
							frameBlankLbl3.setPreferredSize(d3);
							frameBlankLbl3.setBackground(new Color(216,244,248));
								
							add("East",frameBlankLbl3);
								
					//�ϴ� ���鿵��
						JLabel frameBlankLbl4 = new JLabel(" ");
							Dimension d4 = new Dimension(800,80);
							frameBlankLbl4.setOpaque(true);
							frameBlankLbl4.setPreferredSize(d4);
							frameBlankLbl4.setBackground(new Color(216,244,248));
										
							add("South",frameBlankLbl4);
					}
		
		
		
		
		public void actionPerformed(ActionEvent ar) {
			
			String tableBtn = ar.getActionCommand();
			
			if(tableBtn.equals("�ڷΰ���")) {
				setVisible(false);
				new StoreIn();
			}
			if(tableBtn.equals("table1")) {
				
				
			}
		}
		
		
		
		
		public static void main (String args[]) {
			new StoreTable();
		}
		
		
	}


