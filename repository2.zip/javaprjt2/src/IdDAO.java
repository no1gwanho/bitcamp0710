import java.util.ArrayList;
import java.util.List;

public class IdDAO extends DBCon{

	
	
	public IdDAO() {
		
	}

	public static IdDAO getInstance() {
		return new IdDAO();
		
	}
	
	//���ڵ� �߰�
	public int insertRecord(IdVo vo) {
		int result = 0;
		try {
			getConn();
			
			String sql = "insert into Idcon(id, pw, name, idquery)";                    
		
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, vo.getId());
			pstmt.setString(2, vo.getPw());
			pstmt.setString(3, vo.getName());
			pstmt.setString(4, vo.getIdquery());
					
			result = pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			getClose();
		}
		return result;
	}
	
	//���ڵ� ����
	public int updateRecord(IdVo vo) {
		int result=0;
		try {
			getConn();
			String sql = "update Idcon set id=?,pw=?,name=?,idquery=?";
			
		}catch(Exception e) {
					
		}finally {
			getClose();
			
		}
		return result;
					
	}
	
	
	
	public List<IdVo> getAllId(){
		
		List<IdVo> list = new ArrayList<IdVo>();
		try {
			getConn();
			
			//select�� ����~
			String sql="select id, pw from Idcon";
			pstmt = conn.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
			//4�� Vo���� ���� �����ͺ��̽��� ��������
			IdVo vo = new IdVo(rs.getString(1),rs.getString(2));
			list.add(vo);
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			getClose();
		}
		return list;
	}
	
		
	
}
