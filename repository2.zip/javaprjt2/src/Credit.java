import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableModel;

public class Credit extends JFrame implements ActionListener{

	JPanel totalPane = new JPanel(new BorderLayout());
	JPanel paymentTitlePane = new JPanel();
		JLabel paymentLbl = new JLabel("����â");
	
	JPanel paymentCenterTotalPane = new JPanel(new BorderLayout());
	JPanel paymentCenterTitlePane = new JPanel();
		JLabel paymentCenterTitleLbl = new JLabel("�ֹ�����");
	JTextArea paymentTa = new JTextArea();
		JScrollPane paymentSc = new JScrollPane(paymentTa);
		
	
	JPanel BottomMasPane = new JPanel(new BorderLayout());
	
		JPanel paymentType = new JPanel();
			JButton paymentCard = new JButton("ī��");
			JButton paymentCash = new JButton("����");
		JPanel paymentBackPane = new JPanel();
			JButton paymentBack = new JButton("�ڷΰ���");
	
	/////////////������
	JPanel dayFramePane = new JPanel(new BorderLayout());
		
		JPanel dayTitleCpane = new JPanel(new BorderLayout());
			JPanel dayTitlePane = new JPanel();
				JLabel daytitleLbl = new JLabel("�� ���� ��Ȳ");
			JPanel dayBlank1 = new JPanel();
				JLabel dayRefLbl = new JLabel("��ȸ ��");
			JPanel Rblank = new JPanel();	
	//////////////�� ����
			
				
		
				
		JPanel dayTotalPane = new JPanel(new BorderLayout());
			String dayTableTitle[] = {"����/�ð�","����Ǽ�","�ֹ��ݾ�","����","ī��","���"}; 	
			//�ߴ� ���̺� 
			DefaultTableModel dayModel = new DefaultTableModel(dayTableTitle,0);
			JTable daySales = new JTable(dayModel);
			JScrollPane daySp = new JScrollPane(daySales);
			
			
			
			
			//�ϴ� ��ư
			JPanel btnPane = new JPanel(new FlowLayout(FlowLayout.RIGHT));
			JButton dayBackBtn = new JButton("�ڷΰ���");
		
	
		
	public void monthSales() {
			empty();
			
			//��� ����
			dayTitlePane.add(daytitleLbl);
						
			//����� ����
			dayTitleCpane.add("North",dayTitlePane);
			dayTitleCpane.add("West",dayBlank1);
			dayTitleCpane.add("Center",Rblank);
			
			Rblank.setBackground(new Color(216,244,248));
			
			dayBlank1.setBackground(new Color(216,244,248));
			String [] months = {"1��","2��","3��","4��","5��","6��","7��","8��","9��","10��","11��","12��"};
			JComboBox dayCbox = new JComboBox(months);
			dayBlank1.add(dayRefLbl);
			dayBlank1.add(dayCbox);
			
			Font f1 = new Font("",Font.BOLD,20);
			dayTitlePane.setBackground(new Color(43,153,187));
			daytitleLbl.setForeground(Color.white);
			daytitleLbl.setFont(f1);
			
			//�ϴܹ�ư
			btnPane.add(dayBackBtn);
			btnPane.setBackground(new Color(216,244,248));
			
			//�ߴ� ���̺�			
			dayTotalPane.add("Center",daySp);
				
			dayFramePane.add("North",dayTitleCpane);
			dayFramePane.add("Center",dayTotalPane);
			dayFramePane.add("South",btnPane);
			
		add("Center",dayFramePane);
			
		setSize(800,800);		
		setVisible(true);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);			
			
		
		
		dayBackBtn.addActionListener(this);
		
		
		}
	
	public void actionPerformed(ActionEvent ac) {
		String creditBtn = ac.getActionCommand();	
		
		if(creditBtn.equals("�ڷΰ���")) {
			setVisible(false);
			new MainMenu();
			
		}
	
	
	}
		
			
		
	public Credit() {}
		//payment();
		
		
		
	

	public void payment() {
		empty();
		Font f1 = new Font("",Font.BOLD,20);
		Font f2 = new Font("",Font.BOLD ,20);
		
		paymentTitlePane.add(paymentLbl);
		paymentCenterTitleLbl.setFont(f1);
		paymentTitlePane.setBackground(new Color(43,153,187));
		paymentLbl.setForeground(Color.white);
		paymentLbl.setFont(f2);
		
		paymentCenterTotalPane.setBackground(Color.white);
		paymentCenterTotalPane.add("North",paymentCenterTitleLbl);
		paymentCenterTotalPane.add("Center",paymentSc);
		
		
		paymentCard.setBackground(new Color(43,153,187));
		paymentCard.setForeground(Color.white);
		Dimension d1 = new Dimension(150,50);
		paymentCard.setPreferredSize(d1);
		
		
		paymentCash.setBackground(new Color(43,153,187));
		paymentCash.setForeground(Color.white);
		Dimension d3 = new Dimension(150,50);
		paymentCash.setPreferredSize(d3);
		
		Dimension d2 = new Dimension(150,50);
		paymentBack.setPreferredSize(d2);
		paymentBack.setBackground(new Color(43,153,187));
		paymentBack.setForeground(Color.white);
		
		
		
		paymentType.add(paymentCard);
		paymentType.add(paymentCash);
		paymentBackPane.add(paymentBack);
		BottomMasPane.add("North",paymentType);
		BottomMasPane.add("Center",paymentBackPane);		
		
		totalPane.add("North",paymentTitlePane);
		totalPane.add("Center",paymentCenterTotalPane);
		totalPane.add("South",BottomMasPane);
		
		add("Center",totalPane);
				
		setSize(800,800);		
		setVisible(true);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		
		
	}
	

	
	
	
	public void salesReport() {
		
		
	}
	
	
	public void empty() {
		//��� ���鿵��
				JLabel frameBlankLbl = new JLabel(" ");
					Dimension d1 = new Dimension(800,80);
					frameBlankLbl.setOpaque(true);
					frameBlankLbl.setPreferredSize(d1);
					frameBlankLbl.setBackground(new Color(216,244,248));
							
					add("North",frameBlankLbl);
							
							
				//���� ���鿵��
				JLabel frameBlankLbl2 = new JLabel(" ");
					Dimension d2 = new Dimension(120,800);
					frameBlankLbl2.setOpaque(true);
					frameBlankLbl2.setPreferredSize(d2);
					frameBlankLbl2.setBackground(new Color(216,244,248));
							
					add("West",frameBlankLbl2);
											
				//���� ���鿵��
					JLabel frameBlankLbl3 = new JLabel(" ");
						Dimension d3 = new Dimension(120,800);
						frameBlankLbl3.setOpaque(true);
						frameBlankLbl3.setPreferredSize(d3);
						frameBlankLbl3.setBackground(new Color(216,244,248));
							
						add("East",frameBlankLbl3);
							
				//�ϴ� ���鿵��
					JLabel frameBlankLbl4 = new JLabel(" ");
						Dimension d4 = new Dimension(800,80);
						frameBlankLbl4.setOpaque(true);
						frameBlankLbl4.setPreferredSize(d4);
						frameBlankLbl4.setBackground(new Color(216,244,248));
									
						add("South",frameBlankLbl4);
				}
		
		
	
	


}
