import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class AddMenu extends JFrame implements ActionListener{

	//��� ������ �г�
	JPanel adMasPane1 = new JPanel(new BorderLayout());
	
	//��� Ÿ��Ʋ �ڽ�����
	JPanel adPane = new JPanel();
		JLabel adtitle = new JLabel("�޴��߰� ȭ��");
	
	
		
	//�ߴ� �Է¿���
	JPanel adMpane = new JPanel();
		JPanel adLPane = new JPanel(new GridLayout(6,1));
			JLabel adMen = new JLabel("�޴���");
			JLabel adCat = new JLabel("�з�");
			JLabel adPri = new JLabel("�ܰ�");
			JLabel adRem = new JLabel("���");
	
		JPanel adinPane = new JPanel(new GridLayout(6,1));
			JTextField adinMen = new JTextField(40);		JPanel j1 = new JPanel(new FlowLayout(FlowLayout.LEFT));
			JTextField adinCat = new JTextField(30);	JPanel j2 = new JPanel(new FlowLayout(FlowLayout.LEFT));
			JTextField adinPri = new JTextField(40);		JPanel j3 = new JPanel(new FlowLayout(FlowLayout.LEFT));
			JTextField adinRem = new JTextField(20);	JPanel j4 = new JPanel(new FlowLayout(FlowLayout.LEFT));
	

			
	//�ϴ� ������ �г�
	JPanel adMasPane2 = new JPanel(new BorderLayout());		
	//�ߴ� ��ư����
	JPanel adBpane = new JPanel();
		JButton adAddBtn = new JButton("�߰�");
		JButton adRevBtn = new JButton("����");
		JButton adDelBtn = new JButton("����");
		JButton adClearBtn = new JButton("�����");
		JButton adBackBtn = new JButton("�ڷΰ���");
		
		
		
	//�ϴ� ���̺� ����
	String adtabtitle [] = {"No","�޴���","�з�","�ܰ�","���"};	
	DefaultTableModel adModel = new DefaultTableModel(adtabtitle,0);
	JTable adTable = new JTable(adModel);
	JScrollPane adBttn = new JScrollPane(adTable);
		
		
	
	public AddMenu() {
		start();
	}
	public void start() {
		
		//��� ������� �Է¹ڽ�����
		adPane.add(adtitle);	
		
		//�ߴ� ���� �� 
		adLPane.add(adMen);
		adLPane.add(adCat);
		adLPane.add(adPri);
		adLPane.add(adRem);
		
		//�ߴ� �ؽ�Ʈ�ڽ�
		j1.add(adinMen); adinPane.add(j1);
		j2.add(adinCat); adinPane.add(j2);
		j3.add(adinPri); adinPane.add(j3);
		j4.add(adinRem); adinPane.add(j4);
		
				
		adMasPane1.add("North",adPane);	
		adMasPane1.add("West",adLPane);
		adMasPane1.add("Center",adinPane);
			
		
		
		//�ϴ� ��ư�������� ���̺�����..
		adBpane.add(adAddBtn);
		adBpane.add(adRevBtn);
		adBpane.add(adDelBtn); 
		adBpane.add(adClearBtn);
		adBpane.add(adBackBtn);
			
		adMasPane2.add("North",adBpane);
		adMasPane2.add("Center",adBttn);
		
						
		add("North",adMasPane1);
		add(adMasPane2);
		
		
		
		setSize(500,500);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setVisible(true);
	
	
	
		adBackBtn.addActionListener(this);
		
	}
	public void actionPerformed(ActionEvent aw) {
		String addMbtn = aw.getActionCommand();
		
		if(addMbtn.equals("�ڷΰ���")) {
			setVisible(false);
			new StoreIn();
		}
	}
	
	
	
	
	public static void main(String[] args) {
		new AddMenu();

	}

}
