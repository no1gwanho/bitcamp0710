
import java.awt.Canvas;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JFrame;


public class packman2 extends JFrame implements KeyListener{

	
	MyCanvas mc = new MyCanvas();
	
	
	Image img1;
	Image img2;
	Image img3;
	Image img4;
	Image img5;
	Image img6;
	Image img7;
	Image img8;
	
	int x=300;
	int y=300;
	int event=0;
	
	
	public packman2() {
				
		addKeyListener(this);
		setSize(700,700);
		setVisible(true);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE );
		
		add(mc);
		
	}
	
	
		public void keyPressed(KeyEvent e) {
		 event = e.getKeyCode();
		 mc.repaint();
		 
		}
	
	
	
	
	class MyCanvas extends Canvas {
		MyCanvas(){
			img1 = Toolkit.getDefaultToolkit().getImage("img/packman1.jpg");				
			img2 = Toolkit.getDefaultToolkit().getImage("img/packman2.jpg");				
			img3 = Toolkit.getDefaultToolkit().getImage("img/packman3.jpg");				
			img4 = Toolkit.getDefaultToolkit().getImage("img/packman4.jpg");				
			img5 = Toolkit.getDefaultToolkit().getImage("img/packman5.jpg");				
			img6 = Toolkit.getDefaultToolkit().getImage("img/packman6.jpg");				
			img7 = Toolkit.getDefaultToolkit().getImage("img/packman7.jpg");				
			img8 = Toolkit.getDefaultToolkit().getImage("img/packman8.jpg");				
					
		}
		
		
		public void paint(Graphics g) {	
			
		do {			
					
			g.drawImage(img1,x,y,this); 
			x=x-4;
			try {Thread.sleep(300);}catch(Exception e) {}
			g.drawImage(img2,x,y,this); 	
				try {Thread.sleep(300);}catch(Exception e) {}
							
				
				if(event== KeyEvent.VK_LEFT) {
					g.drawImage(img1,x,y,this);
					x=x-4;
				try {Thread.sleep(300);}catch(Exception e) {}
				g.drawImage(img2,x,y,this); 	
				try {Thread.sleep(300);}catch(Exception e) {}
							
				
					
				}else if(event == KeyEvent.VK_RIGHT) {
				  do {
					g.drawImage(img3,x,y,this);
					x=x+4;
					try {Thread.sleep(300);}catch(Exception e) {}
				g.drawImage(img4,x,y,this); 	
					try {Thread.sleep(300);}catch(Exception e) {}
				  }while(true);
				
					
				}else if(event == KeyEvent.VK_UP ) {
					g.drawImage(img5,x,y,this);
					try {Thread.sleep(300);}catch(Exception e) {}
					y=y+4;
				g.drawImage(img6,x,y,this); 	
					try {Thread.sleep(300);}catch(Exception e) {}
				
					
				}else if(event == KeyEvent.VK_DOWN ) {
					
					g.drawImage(img6,x,y,this);
					try {Thread.sleep(300);}catch(Exception e) {}
					y=y-4;
				g.drawImage(img7,x,y,this); 	
					try {Thread.sleep(300);}catch(Exception e) {}
				}	
							
			}while(true);
			
			}
	}
	
	
	
	
	public static void main(String[] args) {
		new packman2();

	}




	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}


}

	







	
