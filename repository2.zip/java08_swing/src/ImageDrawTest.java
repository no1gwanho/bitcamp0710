import java.awt.Canvas;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class ImageDrawTest extends JFrame {

		MyCanvas mc = new MyCanvas();
	
		Image img1;
		Image img2;
		Image img3;
		Image img4;
		Image img5;
		Image img6;
		Image img7;
		Image img8;
		
		
	public ImageDrawTest() {
		super("packman");
					
		add(mc);
				
		
		
		
		
		
		
		
		
		setSize(700,700);
		setVisible(true);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE );
	
	
	
	
	
	
	
	}
	

	
	class MyCanvas extends Canvas {
		MyCanvas(){
			img1 = Toolkit.getDefaultToolkit().getImage("img/packman1.jpg");			
			img2 = Toolkit.getDefaultToolkit().getImage("img/packman2.jpg");
			img3 = Toolkit.getDefaultToolkit().getImage("img/packman3.jpg");
			img4 = Toolkit.getDefaultToolkit().getImage("img/packman4.jpg");
			img5 = Toolkit.getDefaultToolkit().getImage("img/packman5.jpg");
			img6 = Toolkit.getDefaultToolkit().getImage("img/packman6.jpg");
			img7 = Toolkit.getDefaultToolkit().getImage("img/packman7.jpg");
			img8 = Toolkit.getDefaultToolkit().getImage("img/packman8.jpg");
			
		}
		public void paint(Graphics g) {	
			
						
			
			
			
				g.drawImage(img1,150,350,this); 
				g.drawImage(img2,250,150,this); 
				g.drawImage(img3,350,250,this); 
				g.drawImage(img4,450,350,this); 
				g.drawImage(img5,550,550,this); 
				g.drawImage(img6,450,450,this); 
				g.drawImage(img7,150,250,this);
				g.drawImage(img8,450,350,this);
				
			}
	}
	
	public static void main(String[] args) {
		new ImageDrawTest();

	}
	}

