import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Calculator2 extends JFrame implements ActionListener{
	
	
	JPanel pane = new JPanel();
	JPanel pane2 = new JPanel();
	JTextField jf = new JTextField();
	
	JButton j1 = new JButton("1"); 
	JButton j2 = new JButton("2");
	JButton j3 = new JButton("3");
	JButton j4 = new JButton("4");
	JButton j5 = new JButton("5");
	JButton j6 = new JButton("6");
	JButton j7 = new JButton("7");
	JButton j8 = new JButton("8");
	JButton j9 = new JButton("9");
	JButton j0 = new JButton("0");
	JButton jp = new JButton("+");
	JButton jm = new JButton("-");
	JButton jx = new JButton("*");
	JButton jd = new JButton("/");
	
	JButton back = new JButton("Backspace");
	JButton	clear = new JButton("Clear");
	JButton end = new JButton("End");
	
	
	public Calculator2() {
		Dimension d = new Dimension(210,210);
		Dimension d2 = new Dimension(20,20);
		
		pane.setLayout(new GridLayout(0,3));
		pane.add(back);
		pane.add(clear);
		pane.add(end);
		
		pane.setPreferredSize(d2);
		add(BorderLayout.CENTER,pane);
		
		pane2.setLayout(new GridLayout(4,4));
			pane2.add(j1);
			pane2.add(j2);
			pane2.add(j3);
			pane2.add(j4);
			pane2.add(j5);
			pane2.add(j6);
			pane2.add(j7);
			pane2.add(j8);
			pane2.add(j9);
			pane2.add(j0);
			pane2.add(jp);
			pane2.add(jm);
			pane2.add(jx);
			pane2.add(jd);
		
		pane2.setPreferredSize(d);
		add(BorderLayout.SOUTH,pane2);
		
		
		add(BorderLayout.NORTH,jf);
		
				
		setSize(450,310);
		setVisible(true);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
				
	}
	
	
	
	public void actionPerformed(ActionEvent ae) {
		
		String event = ae.getActionCommand();
		if(event.equals("1"));{
				
		int num = Integer.parseInt(j1.getText());
			
			jf.setText(event);
		}
	
	
	
	}
	
	
	public static void main(String[] args) {
		new Calculator2();
		
		
		
		

	}

}
