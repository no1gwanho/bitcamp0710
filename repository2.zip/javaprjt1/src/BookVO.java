
public class BookVO {

	private int index;
	private String bookName;
	private String writer;
	private String publisher;
	private String printDate;
	private int stock;
	private String location;
	private int price;
	
	
	public BookVO() {}


	public  BookVO(int index, String bookName, String writer, String publisher, String printDate, int stock, String location,int price){
		this.index = index;
		this.bookName = bookName;
		this.writer = writer;
		this.publisher = publisher;
		this.printDate = printDate;
		this.stock = stock;
		this.location = location;
		this.price = price;
		
		}			
		                
	
	public void bookOutput() {
		System.out.printf("%d \t%s \t%8s \t%8s \t%8s \t%8d \t%8s \t%8s\n",index, bookName, writer, publisher, printDate, stock, location, price);
				
	}
	
	
	
	

	public int getIndex() {return index;}
	public void setIndex(int index) {	this.index = index;}



	public String getBookName() {return bookName;}	
	public void setBookName(String bookName) {this.bookName = bookName;}
		


	public String getWriter() {return writer;}
	public void setWriter(String writer) {this.writer = writer;}
		


	public String getPublisher() {return publisher;}
	public void setPublisher(String publisher) {this.publisher = publisher;}
		


	public String getPrintDate() {return printDate;}
	public void setPrintDate(String printDate) {this.printDate = printDate;}
		


	public int getStock() {return stock;}
	public void setStock(int stock) {this.stock = stock;}
		


	public String getLocation() {return location;}
	public void setLocation(String location) {this.location = location;}
		


	public int getPrice() {return price;}
	public void setPrice(int price) {this.price = price;}
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
