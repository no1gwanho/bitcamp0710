package com.bitcamp.freeboard;

import java.util.ArrayList;
import java.util.List;

import com.bitcamp.library.DBConnection;

public class FreeboardDAO extends DBConnection{

	//글쓰기
	public int boardInsertRecord(FreeboardVO vo) {
		int cnt=0;
		try {
			
			//1. db연결
			getConn();
			//2. sql -> preparedStatement
			String sql = "insert into freeboard (no,subject,content,userid,hit,writedate,ip) values (a_sq.nextval,?,?,?,0,sysdate,?)";
			
			getPstmt(sql);
			
			pstmt.setString(1, vo.getSubject());
			pstmt.setString(2, vo.getContent());
			pstmt.setString(3, vo.getUserid());
			pstmt.setString(4, vo.getIp());
			
			cnt	= pstmt.executeUpdate();
			
			
		}catch(Exception e) {
			System.out.println("게시판 글 등록에러....."+ e.getMessage());
		}finally {
				
		}
		return cnt;
	}
	
	//글수정
	public int getUpdateRecord(int no, String subject, String content) {						//=>update 쿼리문은 결과에 몇개의 레코드가 수정됐는지에 대한 숫자가 반환이 된다 그러니 반환형으 ㄹint로 잡는다.
	
		int result = 0;
		try {
			getConn();
			
			String sql = "update freeboard set subject=?, content=? where no=?";
			getPstmt(sql);	//preparedstatement를 Pstmt로 셋팅을 해놨음 getConn 클래스를 확인해보자
			
			pstmt.setString(1,subject);//첫번째 물음표는 서브젝
			pstmt.setString(2,content);
			pstmt.setInt(3, no);
			
			result = pstmt.executeUpdate();
				
		}catch(Exception e) {
			System.out.print("글 수정에러가 발생했습니다...."+e.getMessage());
		}finally {
			getClose();
			
		}
		return result ;
	}
		
	//글목록									현재페이지		1페이지당 표시할 레코드수
	public List<FreeboardVO> getAllRecord(int nowPage, int onePageRecord,int totalPage, int totalRecord) {	//각각의 레코드를 담아주는 vo들을 하나로 묶어서 list를 만든다음에 꺼내줄 예쩡임
		List<FreeboardVO> list = new ArrayList<FreeboardVO>();
		try {
			getConn();
			String sql = "select * from"
					+ "(select*from"
					+ "(select no, subject, userid, hit, to_char(writedate,'MM-DD HH:MI') writedate "//줄바꿀때 앞뒤를 띄워줘야함!! 
					+ " from freeboard order by no desc)"
					+ "where rownum<=? order by no asc)"
					+ "where rownum<=? order by no desc";
			getPstmt(sql);
			pstmt.setInt(1, nowPage*onePageRecord);
			
			if(nowPage!=totalPage) {			//현재 페이지가 마지막이냐 아닐때
			pstmt.setInt(2, onePageRecord);
			}else {//마지막 페이지 일때		//남아있는페이지가 나머지가 있던가 혹은 정수로 떨어질때
				int mod = totalRecord%onePageRecord;
				if(mod==0) {
					pstmt.setInt(2, onePageRecord);
				}else {
					pstmt.setInt(2, mod);
				}
				
				
			}
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				FreeboardVO vo = new FreeboardVO();
				vo.setNo(rs.getInt(1));
				vo.setSubject(rs.getString(2));
				vo.setUserid(rs.getString(3));
				vo.setHit(rs.getInt(4));
				vo.setWritedate(rs.getString(5));
				list.add(vo);
			}
			
					
		}catch(Exception e) {
			System.out.println("전체 레코드 선택에러 발생....."+e.getMessage());
			
		}finally {
			getClose();
		}
		return list;
	}
	//레코드 1개 선택
	public FreeboardVO getOneRecordSelect(int no,int part) {
		FreeboardVO vo = new FreeboardVO();
		
		try {
			//조회수 증가
			if(part==1) {
			hitCount(no);
			}
			getConn();
			String sql = "select no,subject,content,userid,hit,writedate from freeboard where no=?";
			
			getPstmt(sql);
			pstmt.setInt(1,no);
			rs = pstmt.executeQuery();
					
			if(rs.next()) {
				vo.setNo(rs.getInt(1));
				vo.setSubject(rs.getString(2));
				vo.setContent(rs.getString(3));
				vo.setUserid(rs.getString(4));
				vo.setHit(rs.getInt(5));
				vo.setWritedate(rs.getString(6));
			}
			
						
		}catch(Exception e) {
			System.out.println("레코드 선택에러 발생...."+e.getMessage());
		}finally {
			getClose();
			
		}
		return vo;
	}
	
	//글삭제
	public int getDeleteRecord(int no) {
		int result = 0;
		try {
			getConn();
			String sql = "delete from freeboard where no=?";
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, no);
			result = pstmt.executeUpdate();
		
		}catch(Exception e) {
			System.out.print("레코드 삭제 에러발생..."+e.getMessage());
		}finally {
		 getClose();
			
		}return result;
		
		
	}
	
	
	
	
	
	
	//조회수증가
	public void hitCount(int no) {
		try {
			
			getConn();
			String sql = "update freeboard set hit=hit+1 where no=?";
			getPstmt(sql);
			pstmt.setInt(1, no);//물음표를 세팅해주는 작업임
			pstmt.executeUpdate();
		}catch(Exception e) {
			System.out.println("조회수 증가 에러 발생..."+e.getMessage());
		}finally {
			getClose();
		}
	}
	
	//총레코드 수
	public int getTotalRecord() {
		int totalRecord=0;
		try {
			getConn();
			String sql = "select count(no) from freeboard";
			getPstmt(sql);	//dbconnection 에서 만든곳에 변수만 넣어줌
			
			rs = pstmt.executeQuery();
			if(rs.next()) {
				totalRecord = rs.getInt(1);
				
			}
					
		}catch(Exception e) {
			System.out.println("총레코드 수 구하기에서 에러발생..."+e.getMessage());
		}finally {
			getClose();
		}
		return totalRecord;
	}

		
	
	
}
